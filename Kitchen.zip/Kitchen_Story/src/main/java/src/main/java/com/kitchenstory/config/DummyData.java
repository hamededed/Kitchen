package com.kitchenstory.config;

//@Component
//@AllArgsConstructor
public class DummyData  {
//public class DummyData implements CommandLineRunner {
//
//    private final UserService service;
//
//    @Override
//    public void run(String... args) throws Exception {
//
//        final UserEntity admin = new UserEntity("Riyaz J", "j.riyazu@gmail.com", "Male",
//                "$2a$10$jBe5RX4UmG0S1Vge0DVQ4OSFXSKag4QFMxnX1M1Jh08KlDUOnh1Dm", "B.Kothakota",
//                "B.Kothakota", "Andhra Pradesh", "517370", true, true,
//                true, true, true, UserRole.ROLE_ADMIN);
//
//        service.save(admin);
//    }
}
